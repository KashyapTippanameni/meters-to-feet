a=input()
a=float(a)
print(a*3.281)